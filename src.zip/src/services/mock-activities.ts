export let ACTIVITIES = []
